import aiohttp

class GoodWeClient:
    def __init__(self, username: str, password: str):
        self.base_url = "https://eu.semsportal.com/api/v2"
        self.username = username
        self.password = password
        self.token = None

    async def login(self):
        async with aiohttp.ClientSession() as session:
            payload = {"account": self.username, "pwd": self.password}
            headers = {"Content-Type": "application/json"}
            async with session.post(f"{self.base_url}/Common/CrossLogin", json=payload, headers=headers) as resp:
                data = await resp.json()
                if data["type"] != "success":
                    raise Exception("Login failed")
                self.token = data["data"]["token"]

    async def _get(self, endpoint: str, params: dict = {}):
        if not self.token:
            await self.login()
        headers = {
            "Token": self.token,
            "Content-Type": "application/json",
        }
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.get(f"{self.base_url}/{endpoint}", params=params) as resp:
                return await resp.json()

    async def get_plants(self):
        return await self._get("PowerStation/GetPowerStationList")

    async def get_plant_detail(self, plant_id: str):
        return await self._get("PowerStation/GetMonitorDetailByPowerstationId", {"powerStationId": plant_id})