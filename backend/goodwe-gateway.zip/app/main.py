from fastapi import FastAPI, Depends
from app.goodwe_client import GoodWeClient
from fastapi import HTTPException
import os

app = FastAPI(title="GoodWe Gateway API")

def get_client():
    return GoodWeClient(
        username=os.getenv("GOODWE_EMAIL"),
        password=os.getenv("GOODWE_PASSWORD")
    )

@app.get("/plants")
async def get_plants(client: GoodWeClient = Depends(get_client)):
    try:
        return await client.get_plants()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/status/{plant_id}")
async def get_status(plant_id: str, client: GoodWeClient = Depends(get_client)):
    try:
        return await client.get_plant_detail(plant_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))