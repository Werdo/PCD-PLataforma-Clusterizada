from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from app.core.manager import manager
import os

app = FastAPI(title="PCD WebSocket Service")

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await manager.connect(websocket, client_id)
    try:
        while True:
            data = await websocket.receive_text()
            await manager.broadcast(f"[{client_id}] {data}")
    except WebSocketDisconnect:
        manager.disconnect(client_id)
        await manager.broadcast(f"{client_id} disconnected")