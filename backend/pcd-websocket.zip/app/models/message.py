from pydantic import BaseModel
from typing import Optional

class Message(BaseModel):
    sender: str
    type: str  # "event", "command", "log"
    content: str
    target: Optional[str] = None