from fastapi import APIRouter
from app.models.zone import GeoZone

router = APIRouter(prefix="/geofence", tags=["geofence"])

zones_db = []

@router.get("/")
def get_zones():
    return zones_db

@router.post("/")
def add_zone(zone: GeoZone):
    zones_db.append(zone)
    return {"status": "zone added", "zone": zone}