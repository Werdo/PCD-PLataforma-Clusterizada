from fastapi import APIRouter
from app.models.alert import Alert

router = APIRouter(prefix="/alerts", tags=["alerts"])

alerts_db = []

@router.get("/")
def get_alerts():
    return alerts_db

@router.post("/")
def create_alert(alert: Alert):
    alerts_db.append(alert)
    return {"status": "created", "alert": alert}