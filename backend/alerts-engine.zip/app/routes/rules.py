from fastapi import APIRouter
from app.models.rule import Rule

router = APIRouter(prefix="/rules", tags=["rules"])

rules_db = []

@router.get("/")
def get_rules():
    return rules_db

@router.post("/")
def add_rule(rule: Rule):
    rules_db.append(rule)
    return {"status": "rule added", "rule": rule}