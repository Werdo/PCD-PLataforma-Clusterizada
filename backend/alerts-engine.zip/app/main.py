from fastapi import FastAPI
from app.routes import alerts, rules, geofence

app = FastAPI(title="PCD Alerts Engine")

app.include_router(alerts.router)
app.include_router(rules.router)
app.include_router(geofence.router)

@app.get("/")
def root():
    return {"status": "Alerts Engine activo"}