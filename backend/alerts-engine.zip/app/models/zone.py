from pydantic import BaseModel

class GeoZone(BaseModel):
    id: str
    name: str
    lat: float
    lon: float
    radius: float  # en metros