from pydantic import BaseModel
from typing import List, Optional

class Rule(BaseModel):
    id: str
    type: str  # "value" or "geofence"
    threshold: Optional[float]
    zones: Optional[List[dict]]
    direction: Optional[str]  # "enter" or "exit"