from pydantic import BaseModel
from typing import Optional

class Alert(BaseModel):
    source: str
    message: str
    type: str
    confirmed: Optional[bool] = False