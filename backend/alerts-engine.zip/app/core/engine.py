from app.models.alert import Alert
from app.models.rule import Rule
from app.models.zone import GeoZone
from geopy.distance import geodesic

def evaluate_trigger(data, rules):
    alerts = []
    for rule in rules:
        if rule["type"] == "value":
            if data["value"] > rule["threshold"]:
                alerts.append(Alert(
                    source=data["source"],
                    message=f"Valor excedido: {data['value']} > {rule['threshold']}",
                    type="threshold"
                ))
        elif rule["type"] == "geofence":
            for zone in rule["zones"]:
                inside = is_inside_zone(data["location"], zone)
                if rule["direction"] == "exit" and not inside:
                    alerts.append(Alert(
                        source=data["source"],
                        message=f"Dispositivo salió de zona: {zone['name']}",
                        type="geofence"
                    ))
                elif rule["direction"] == "enter" and inside:
                    alerts.append(Alert(
                        source=data["source"],
                        message=f"Dispositivo entró en zona: {zone['name']}",
                        type="geofence"
                    ))
    return alerts

def is_inside_zone(location, zone):
    center = (zone["lat"], zone["lon"])
    distance = geodesic(center, (location["lat"], location["lon"])).meters
    return distance <= zone["radius"]