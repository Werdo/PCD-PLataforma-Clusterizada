import requests
import hashlib
import hmac
import time
import uuid
import os

class TuyaClient:
    def __init__(self):
        self.client_id = os.getenv("TUYA_CLIENT_ID")
        self.secret = os.getenv("TUYA_CLIENT_SECRET")
        self.base_url = "https://openapi.tuyaeu.com"
        self.access_token = None
        self.refresh_token = None

    def _sign(self, t, method="GET", path="/v1.0/token", body=""):
        string_to_sign = f"{method}\n{body}\n\n{path}"
        sign_str = self.client_id + self.access_token if self.access_token else self.client_id
        sign_str += str(t) + string_to_sign
        return hmac.new(self.secret.encode(), sign_str.encode(), hashlib.sha256).hexdigest().upper()

    def authenticate(self):
        t = int(time.time() * 1000)
        sign = self._sign(t)
        headers = {
            "client_id": self.client_id,
            "sign": sign,
            "t": str(t),
            "sign_method": "HMAC-SHA256"
        }
        resp = requests.get(f"{self.base_url}/v1.0/token?grant_type=1", headers=headers)
        data = resp.json()
        self.access_token = data["result"]["access_token"]
        self.refresh_token = data["result"]["refresh_token"]

    def _headers(self, path, method="GET", body=""):
        t = int(time.time() * 1000)
        sign = self._sign(t, method=method, path=path, body=body)
        return {
            "client_id": self.client_id,
            "access_token": self.access_token,
            "sign": sign,
            "t": str(t),
            "sign_method": "HMAC-SHA256"
        }

    def get_devices(self):
        path = "/v1.0/devices"
        headers = self._headers(path)
        resp = requests.get(self.base_url + path, headers=headers)
        return resp.json()

    def get_status(self, device_id):
        path = f"/v1.0/devices/{device_id}/status"
        headers = self._headers(path)
        resp = requests.get(self.base_url + path, headers=headers)
        return resp.json()

    def send_command(self, device_id, command):
        path = f"/v1.0/devices/{device_id}/commands"
        headers = self._headers(path, method="POST", body="")
        resp = requests.post(self.base_url + path, headers=headers, json={"commands": command})
        return resp.json()