from fastapi import APIRouter
from app.core.tuya_client import TuyaClient
from app.models.device import devices_db

router = APIRouter(prefix="/devices", tags=["devices"])

@router.get("/")
def list_devices():
    client = TuyaClient()
    client.authenticate()
    result = client.get_devices()
    for dev in result.get("result", []):
        devices_db[dev["id"]] = dev
    return list(devices_db.values())