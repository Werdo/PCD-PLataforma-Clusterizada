from fastapi import APIRouter, HTTPException
from app.core.tuya_client import TuyaClient

router = APIRouter(prefix="/status", tags=["status"])

@router.get("/{device_id}")
def get_status(device_id: str):
    client = TuyaClient()
    client.authenticate()
    return client.get_status(device_id)