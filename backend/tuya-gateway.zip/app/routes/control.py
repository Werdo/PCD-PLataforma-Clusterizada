from fastapi import APIRouter, HTTPException
from app.core.tuya_client import TuyaClient

router = APIRouter(prefix="/control", tags=["control"])

@router.post("/{device_id}/on")
def turn_on(device_id: str):
    client = TuyaClient()
    client.authenticate()
    return client.send_command(device_id, [{"code": "switch", "value": True}])

@router.post("/{device_id}/off")
def turn_off(device_id: str):
    client = TuyaClient()
    client.authenticate()
    return client.send_command(device_id, [{"code": "switch", "value": False}])