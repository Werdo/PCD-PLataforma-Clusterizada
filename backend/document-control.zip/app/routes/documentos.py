from fastapi import APIRouter
from app.models.documento import Documento
from typing import List

router = APIRouter(prefix="/documentos", tags=["documentos"])

db_documentos = []

@router.get("/", response_model=List[Documento])
def listar_documentos():
    return db_documentos

@router.post("/", response_model=Documento)
def subir_documento(d: Documento):
    db_documentos.append(d)
    return d