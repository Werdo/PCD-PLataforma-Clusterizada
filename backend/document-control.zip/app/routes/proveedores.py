from fastapi import APIRouter
from app.models.proveedor import Proveedor
from typing import List

router = APIRouter(prefix="/proveedores", tags=["proveedores"])

# Simulación de almacenamiento en memoria
db_proveedores = []

@router.get("/", response_model=List[Proveedor])
def listar_proveedores():
    return db_proveedores

@router.post("/", response_model=Proveedor)
def crear_proveedor(p: Proveedor):
    db_proveedores.append(p)
    return p