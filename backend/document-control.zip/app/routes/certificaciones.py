from fastapi import APIRouter
from app.models.certificacion import Certificacion
from typing import List

router = APIRouter(prefix="/certificaciones", tags=["certificaciones"])

db_certs = []

@router.get("/", response_model=List[Certificacion])
def listar_certificaciones():
    return db_certs

@router.post("/", response_model=Certificacion)
def agregar_certificacion(c: Certificacion):
    db_certs.append(c)
    return c