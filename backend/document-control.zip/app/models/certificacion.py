from pydantic import BaseModel
from typing import Optional
from datetime import date

class Certificacion(BaseModel):
    proveedor: str
    nombre: str
    estado: Optional[str]
    fecha_valoracion: Optional[date]