from fastapi import FastAPI
from app.routes import usuarios, depositos, barricas

app = FastAPI(title="DataWine Gateway")

app.include_router(usuarios.router)
app.include_router(depositos.router)
app.include_router(barricas.router)

@app.get("/")
def root():
    return {"status": "DataWine Gateway operativo"}