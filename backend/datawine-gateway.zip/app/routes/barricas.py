from fastapi import APIRouter
from app.core.client import api_get

router = APIRouter(prefix="/barricas", tags=["barricas"])

@router.get("/")
def listar_barricas():
    return api_get("/api/v1/barrica")

@router.get("/{id}")
def barrica_por_id(id: str):
    return api_get(f"/api/v1/barrica/{id}")