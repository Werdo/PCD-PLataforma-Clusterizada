from fastapi import APIRouter, Query
from app.core.client import api_get

router = APIRouter(prefix="/usuarios", tags=["usuarios"])

@router.get("/")
def listar_usuarios():
    return api_get("/api/v1/usuario")

@router.get("/{user_id}")
def usuario_por_id(user_id: str):
    return api_get(f"/api/v1/usuario/{user_id}")