from fastapi import APIRouter
from app.core.client import api_get

router = APIRouter(prefix="/depositos", tags=["depositos"])

@router.get("/")
def listar_depositos():
    return api_get("/api/v1/deposito")

@router.get("/{dep_id}")
def deposito_por_id(dep_id: str):
    return api_get(f"/api/v1/deposito/{dep_id}")