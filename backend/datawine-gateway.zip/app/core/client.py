import requests
import os

BASE_URL = os.getenv("DATAWINE_API", "https://api.datawine.io")

def api_get(path: str, params: dict = {}):
    url = f"{BASE_URL}{path}"
    resp = requests.get(url, params=params)
    return resp.json()