from fastapi import APIRouter
from app.core.schneider_client import SchneiderClient

router = APIRouter(prefix="/sites", tags=["sites"])

@router.get("/")
def list_sites():
    client = SchneiderClient()
    return client.get_sites()