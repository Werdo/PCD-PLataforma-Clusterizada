from fastapi import APIRouter
from app.core.schneider_client import SchneiderClient

router = APIRouter(prefix="/consumption", tags=["consumption"])

@router.get("/{site_id}")
def get_site_consumption(site_id: str):
    client = SchneiderClient()
    return client.get_consumption(site_id)