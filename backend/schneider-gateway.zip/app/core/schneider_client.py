import os
import requests

class SchneiderClient:
    def __init__(self):
        self.auth_url = "https://resourceadvisor.schneider-electric.com/api/oauth/token"
        self.api_base = "https://resourceadvisor.schneider-electric.com/api"
        self.client_id = os.getenv("SCHNEIDER_CLIENT_ID")
        self.client_secret = os.getenv("SCHNEIDER_CLIENT_SECRET")
        self.token = self.get_token()

    def get_token(self):
        response = requests.post(self.auth_url, data={
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret
        })
        response.raise_for_status()
        return response.json()["access_token"]

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json"
        }

    def get_sites(self):
        url = f"{self.api_base}/reporting/api/sites"
        response = requests.get(url, headers=self._headers())
        response.raise_for_status()
        return response.json()

    def get_consumption(self, site_id):
        url = f"{self.api_base}/reporting/api/consumption/site/{site_id}"
        response = requests.get(url, headers=self._headers())
        response.raise_for_status()
        return response.json()