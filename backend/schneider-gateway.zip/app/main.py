from fastapi import FastAPI
from app.routes import sites, consumption

app = FastAPI(title="Schneider Gateway API")

app.include_router(sites.router)
app.include_router(consumption.router)

@app.get("/")
def root():
    return {"status": "Schneider Gateway operativo"}