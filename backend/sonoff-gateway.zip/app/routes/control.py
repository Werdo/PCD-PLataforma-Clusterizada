from fastapi import APIRouter, HTTPException
from app.models.device import devices_db
from app.core.sonoff import SonoffDevice

router = APIRouter(prefix="/control", tags=["control"])

@router.post("/{device_id}/on")
async def turn_on(device_id: str):
    device = devices_db.get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return await SonoffDevice(device).turn_on()

@router.post("/{device_id}/off")
async def turn_off(device_id: str):
    device = devices_db.get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return await SonoffDevice(device).turn_off()