from fastapi import APIRouter, HTTPException
from app.models.device import devices_db
from app.core.sonoff import SonoffDevice

router = APIRouter(prefix="/status", tags=["status"])

@router.get("/{device_id}")
async def get_status(device_id: str):
    device = devices_db.get(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return await SonoffDevice(device).get_status()