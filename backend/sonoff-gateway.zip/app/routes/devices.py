from fastapi import APIRouter
from app.core.discovery import discover_devices
from app.models.device import devices_db

router = APIRouter(prefix="/devices", tags=["devices"])

@router.get("/")
async def list_devices():
    return list(devices_db.values())

@router.post("/discover")
async def run_discovery():
    new_devices = await discover_devices()
    return {"detected": len(new_devices), "devices": new_devices}