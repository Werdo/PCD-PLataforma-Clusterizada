from typing import Dict

# Simulación de base de datos en memoria
devices_db: Dict[str, dict] = {}