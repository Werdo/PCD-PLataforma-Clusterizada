import asyncio
from app.models.device import devices_db
import random

# Simulación del descubrimiento LAN
async def discover_devices():
    mock = [{"deviceid": f"sonoff_{i}", "ip": f"192.168.1.{100+i}"} for i in range(1, 4)]
    for dev in mock:
        devices_db[dev["deviceid"]] = dev
    await asyncio.sleep(1)
    return mock