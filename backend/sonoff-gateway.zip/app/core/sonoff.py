import asyncio
import random

class SonoffDevice:
    def __init__(self, data):
        self.device_id = data["deviceid"]
        self.ip = data["ip"]

    async def turn_on(self):
        await asyncio.sleep(0.2)
        return {"device": self.device_id, "action": "on", "success": True}

    async def turn_off(self):
        await asyncio.sleep(0.2)
        return {"device": self.device_id, "action": "off", "success": True}

    async def get_status(self):
        await asyncio.sleep(0.2)
        return {"device": self.device_id, "state": random.choice(["on", "off"]), "ip": self.ip}