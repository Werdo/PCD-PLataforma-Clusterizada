from fastapi import FastAPI
from app.routes import devices, control, status

app = FastAPI(title="Sonoff Gateway API")

app.include_router(devices.router)
app.include_router(control.router)
app.include_router(status.router)

@app.get("/")
def root():
    return {"status": "Sonoff Gateway operativo"}