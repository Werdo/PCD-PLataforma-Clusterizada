#!/bin/bash
echo "🚀 Construyendo imagen Docker para tuya-gateway..."
docker build -t ppelaez/tuya-gateway:latest .

echo "📤 Subiendo imagen a Docker Hub..."
docker push ppelaez/tuya-gateway:latest

echo "🧱 Aplicando deployment y service..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml

echo "🌐 Aplicando Ingress..."
kubectl apply -f ingress.yaml

echo "✅ Despliegue completo de tuya-gateway realizado."