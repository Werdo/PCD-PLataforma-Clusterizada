#!/bin/bash
echo "🚀 Desplegando schneider-gateway..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl rollout status deployment/schneider-gateway