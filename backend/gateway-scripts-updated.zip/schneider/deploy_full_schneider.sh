#!/bin/bash
echo "🚀 Construyendo imagen Docker para schneider-gateway..."
docker build -t ppelaez/schneider-gateway:latest .

echo "📤 Subiendo imagen a Docker Hub..."
docker push ppelaez/schneider-gateway:latest

echo "🧱 Aplicando deployment y service..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml

echo "🌐 Aplicando Ingress..."
kubectl apply -f ingress.yaml

echo "✅ Despliegue completo de schneider-gateway realizado."