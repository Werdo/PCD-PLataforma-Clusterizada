#!/bin/bash
echo "🚀 Desplegando daikin-gateway..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl rollout status deployment/daikin-gateway