#!/bin/bash
echo "🚀 Desplegando sigena-gateway..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl rollout status deployment/sigena-gateway