#!/bin/bash
echo "🚀 Desplegando tuya-gateway..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl rollout status deployment/tuya-gateway