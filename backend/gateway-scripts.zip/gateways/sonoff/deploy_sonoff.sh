#!/bin/bash
echo "🚀 Desplegando sonoff-gateway..."
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl rollout status deployment/sonoff-gateway