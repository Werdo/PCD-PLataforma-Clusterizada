#!/bin/bash
echo "=== GATEWAY DEPLOYER MENU ==="
echo "Seleccione el gateway a desplegar:"
options=("goodwe" "sonoff" "tuya" "schneider" "sigena" "daikin" "salir")
select opt in "${options[@]}"
do
    case $opt in
        "goodwe"|"sonoff"|"tuya"|"schneider"|"sigena"|"daikin")
            bash "./gateways/$opt/deploy_$opt.sh"
            break;;
        "salir")
            echo "Abortado."
            break;;
        *) echo "Opción inválida.";;
    esac
done
