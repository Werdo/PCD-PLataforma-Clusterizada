from fastapi import APIRouter, HTTPException
from app.models.documento import Documento
from typing import List
import requests

router = APIRouter(prefix="/documentos", tags=["documentos"])

db_documentos = []

DOC_VALIDATOR_URL = "http://doc-validator:8092/validate/"
ALERTS_ENGINE_URL = "http://alerts-engine:8090/alerts"

@router.get("/", response_model=List[Documento])
def listar_documentos():
    return db_documentos

@router.post("/", response_model=Documento)
def subir_documento(d: Documento):
    db_documentos.append(d)
    try:
        # Simulación de envío a doc-validator
        validator_response = requests.post(DOC_VALIDATOR_URL, files={"file": ("document.png", b"placeholder")})
        result = validator_response.json()
        if not result.get("valid", True):
            alert = {
                "source": d.proveedor,
                "message": f"Documento inválido: {', '.join(result.get('issues', []))}",
                "type": "document"
            }
            requests.post(ALERTS_ENGINE_URL, json=alert)
    except Exception as e:
        print("Error validando documento o enviando alerta:", e)
    return d