from pydantic import BaseModel
from typing import Optional
from datetime import date

class Proveedor(BaseModel):
    ref: Optional[str]
    nombre: str
    categoria: Optional[str]
    fecha_alta: Optional[date]
    fecha_renovacion: Optional[date]
    estado: Optional[str]
    observaciones: Optional[str]
    contacto: Optional[str]
    email: Optional[str]
    telefono: Optional[str]