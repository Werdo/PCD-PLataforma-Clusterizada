from pydantic import BaseModel
from typing import Optional
from datetime import date

class Documento(BaseModel):
    proveedor: str
    tipo: str
    fecha_subida: Optional[date]
    fecha_vencimiento: Optional[date]
    estado: Optional[str]