from fastapi import FastAPI
from app.routes import proveedores, documentos, certificaciones

app = FastAPI(title="Document Control - Proveedores")

app.include_router(proveedores.router)
app.include_router(documentos.router)
app.include_router(certificaciones.router)

@app.get("/")
def root():
    return {"status": "document-control operativo"}