import os

class SigenaClient:
    def __init__(self):
        self.base_url = os.getenv("SIGENA_API_URL", "https://api.sigena.es")
        self.api_key = os.getenv("SIGENA_API_KEY", "dummy-key")

    def get_devices(self):
        # Placeholder simulado
        return [{"id": "device-001", "name": "SIGENA sensor A"}, {"id": "device-002", "name": "SIGENA actuator B"}]

    def get_device_status(self, device_id):
        # Placeholder simulado
        return {"id": device_id, "status": "online", "last_update": "2024-06-01T12:00:00Z"}