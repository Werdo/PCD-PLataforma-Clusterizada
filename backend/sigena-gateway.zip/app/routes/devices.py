from fastapi import APIRouter
from app.core.sigena_client import SigenaClient

router = APIRouter(prefix="/devices", tags=["devices"])

@router.get("/")
def list_devices():
    client = SigenaClient()
    return client.get_devices()

@router.get("/{device_id}/status")
def get_device_status(device_id: str):
    client = SigenaClient()
    return client.get_device_status(device_id)