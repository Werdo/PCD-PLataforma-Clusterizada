from fastapi import FastAPI
from app.routes import devices

app = FastAPI(title="SIGENA Gateway")

app.include_router(devices.router)

@app.get("/")
def root():
    return {"status": "SIGENA Gateway operativo"}