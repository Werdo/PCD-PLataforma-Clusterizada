from fastapi import FastAPI
from app.routes import devices, control

app = FastAPI(title="Daikin Gateway")

app.include_router(devices.router)
app.include_router(control.router)

@app.get("/")
def root():
    return {"status": "Daikin Gateway operativo"}