import requests

# Simulación de descubrimiento (IPs conocidas o escaneadas manualmente)
def discover_devices():
    return [
        {"ip": "192.168.1.101", "name": "Daikin Sala 1"},
        {"ip": "192.168.1.102", "name": "Daikin Oficina A"}
    ]

def get_status(ip):
    url = f"http://{ip}/skyfi/aircon/get_control_info"
    resp = requests.get(url)
    return resp.json()

def send_command(ip, payload):
    url = f"http://{ip}/skyfi/aircon/set_control_info"
    resp = requests.get(url, params=payload)
    return {"status": resp.status_code, "response": resp.text}