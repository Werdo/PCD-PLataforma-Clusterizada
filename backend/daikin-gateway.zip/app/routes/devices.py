from fastapi import APIRouter
from app.core.daikin_client import discover_devices

router = APIRouter(prefix="/devices", tags=["devices"])

@router.get("/")
def listar_dispositivos():
    return discover_devices()