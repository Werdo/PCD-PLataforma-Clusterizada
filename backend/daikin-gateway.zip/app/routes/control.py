from fastapi import APIRouter, HTTPException
from app.core.daikin_client import get_status, send_command

router = APIRouter(prefix="/control", tags=["control"])

@router.get("/{device_ip}/status")
def estado_dispositivo(device_ip: str):
    return get_status(device_ip)

@router.post("/{device_ip}/command")
def controlar_dispositivo(device_ip: str, payload: dict):
    try:
        return send_command(device_ip, payload)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))