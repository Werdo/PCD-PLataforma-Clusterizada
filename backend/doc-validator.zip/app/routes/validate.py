from fastapi import APIRouter, UploadFile, File
from app.core.ocr import extract_text
from app.core.rules import validate_text

router = APIRouter(prefix="/validate", tags=["documentos"])

@router.post("/")
async def validate_document(file: UploadFile = File(...)):
    contents = await file.read()
    text = extract_text(contents)
    result = validate_text(text)
    return {
        "filename": file.filename,
        "valid": result["valid"],
        "issues": result["issues"]
    }