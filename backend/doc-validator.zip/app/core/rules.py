def validate_text(text: str):
    issues = []
    if "certificado" not in text.lower():
        issues.append("Falta la palabra 'certificado'")
    if "validado" not in text.lower():
        issues.append("Falta 'validado' o no está explícito")
    if "202" not in text:
        issues.append("No se detecta ninguna fecha válida")
    return {
        "valid": len(issues) == 0,
        "issues": issues
    }