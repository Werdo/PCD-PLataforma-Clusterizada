from fastapi import FastAPI
from app.routes import validate

app = FastAPI(title="Document Validator")

app.include_router(validate.router)

@app.get("/")
def root():
    return {"status": "doc-validator operativo"}