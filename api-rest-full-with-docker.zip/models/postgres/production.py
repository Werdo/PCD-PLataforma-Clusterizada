
from sqlalchemy import Column, String, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID, JSONB
from database.postgres import Base
import uuid

class ProcesoProduccion(Base):
    __tablename__ = "procesos_produccion"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tipo_proceso = Column(String)
    objeto_id = Column(UUID(as_uuid=True))
    fecha_inicio = Column(DateTime)
    fecha_fin = Column(DateTime)
    resultado = Column(JSONB)
