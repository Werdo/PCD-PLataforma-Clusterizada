
from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class SistemaIluminacion(Base):
    __tablename__ = "sistemas_iluminacion"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    nombre = Column(String)
    tipo = Column(String)
    ubicacion_id = Column(UUID(as_uuid=True), ForeignKey("ubicaciones.id"))

class EstadoIluminacion(Base):
    __tablename__ = "estados_iluminacion"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sistema_id = Column(UUID(as_uuid=True), ForeignKey("sistemas_iluminacion.id"))
    timestamp = Column(DateTime)
    estado = Column(String)
    activo = Column(Boolean)
