
from sqlalchemy import Column, String, Integer
from database.postgres import Base

class CatalogoTipo(Base):
    __tablename__ = "catalogo_tipos"
    id = Column(Integer, primary_key=True, index=True)
    grupo = Column(String)
    nombre = Column(String)
    descripcion = Column(String)

class Unidad(Base):
    __tablename__ = "unidades"
    id = Column(Integer, primary_key=True, index=True)
    simbolo = Column(String)
    nombre = Column(String)
    tipo = Column(String)

class Configuracion(Base):
    __tablename__ = "configuraciones"
    clave = Column(String, primary_key=True)
    valor = Column(String)
    tipo_valor = Column(String)

class TipoVino(Base):
    __tablename__ = "tipos_vino"
    id = Column(Integer, primary_key=True)
    nombre = Column(String)
    descripcion = Column(String)

class TipoUva(Base):
    __tablename__ = "tipos_uva"
    id = Column(Integer, primary_key=True)
    nombre = Column(String)
    caracteristicas = Column(String)

class Añada(Base):
    __tablename__ = "anadas"
    id = Column(Integer, primary_key=True)
    año = Column(Integer)
    estado_climatico = Column(String)
    observaciones = Column(String)
