
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Sensor(Base):
    __tablename__ = "sensores"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dispositivo_id = Column(UUID(as_uuid=True), ForeignKey("dispositivos.id"))
    tipo_sensor = Column(String)
    unidad_medida = Column(String)
    rango_operativo = Column(String)
