
from sqlalchemy import Column, String, Float, ForeignKey, Integer
from database.postgres import Base

class ValorOrganolepticoUva(Base):
    __tablename__ = "valores_organolepticos_uva"
    id = Column(Integer, primary_key=True)
    tipo_uva_id = Column(Integer, ForeignKey("tipos_uva.id"))
    tipo_valor = Column(String)
    valor = Column(Float)

class ValorOrganolepticoVino(Base):
    __tablename__ = "valores_organolepticos_vino"
    id = Column(Integer, primary_key=True)
    tipo_vino_id = Column(Integer, ForeignKey("tipos_vino.id"))
    tipo_valor = Column(String)
    valor = Column(Float)
