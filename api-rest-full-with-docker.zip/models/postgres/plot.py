
from sqlalchemy import Column, String, Float, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Parcela(Base):
    __tablename__ = "parcelas"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    nombre = Column(String, nullable=False)
    ubicacion_id = Column(UUID(as_uuid=True), ForeignKey("ubicaciones.id"))
    superficie = Column(Float)
    tipo_tenencia = Column(String)
    activo = Column(Boolean, default=True)
