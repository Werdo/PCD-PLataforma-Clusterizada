
from sqlalchemy import Column, String, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Dispositivo(Base):
    __tablename__ = "dispositivos"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tipo = Column(String)
    marca = Column(String)
    modelo = Column(String)
    ubicacion_id = Column(UUID(as_uuid=True), ForeignKey("ubicaciones.id"))
    activo = Column(Boolean, default=True)
