
from sqlalchemy import Column, String, Float, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Barrica(Base):
    __tablename__ = "barricas"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tipo_madera = Column(String)
    volumen = Column(Float)
    ubicacion_id = Column(UUID(as_uuid=True), ForeignKey("salas.id"))
