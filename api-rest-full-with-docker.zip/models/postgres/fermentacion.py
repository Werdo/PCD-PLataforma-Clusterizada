
from sqlalchemy import Column, String, Float, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class ValorFermentacion(Base):
    __tablename__ = "valores_fermentacion"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    proceso_id = Column(UUID(as_uuid=True), ForeignKey("procesos_produccion.id"))
    tipo_valor = Column(String)
    valor = Column(Float)
    timestamp = Column(DateTime)
