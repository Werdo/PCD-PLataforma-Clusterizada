
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Cuadricula(Base):
    __tablename__ = "cuadriculas"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    parcela_id = Column(UUID(as_uuid=True), ForeignKey("parcelas.id"))
    nombre_local = Column(String)
    coordenadas = Column(String)
    uso = Column(String)
