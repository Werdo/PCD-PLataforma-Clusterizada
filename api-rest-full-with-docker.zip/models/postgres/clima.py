
from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class SistemaClima(Base):
    __tablename__ = "sistemas_clima"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    nombre = Column(String)
    tipo = Column(String)
    ubicacion_id = Column(UUID(as_uuid=True), ForeignKey("ubicaciones.id"))

class EstadoClima(Base):
    __tablename__ = "estados_clima"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sistema_id = Column(UUID(as_uuid=True), ForeignKey("sistemas_clima.id"))
    timestamp = Column(DateTime)
    estado = Column(String)
    activo = Column(Boolean)
