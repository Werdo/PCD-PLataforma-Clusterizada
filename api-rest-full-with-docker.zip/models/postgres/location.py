
from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Ubicacion(Base):
    __tablename__ = "ubicaciones"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    nombre = Column(String, nullable=False)
    tipo = Column(String, nullable=False)
    coordenadas = Column(String)
    ubicacion_padre_id = Column(UUID(as_uuid=True), ForeignKey("ubicaciones.id"))
