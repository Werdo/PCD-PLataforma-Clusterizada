
from sqlalchemy import Column, String, ForeignKey, Date
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class SensorCampo(Base):
    __tablename__ = "sensores_campo"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    cuadrícula_id = Column(UUID(as_uuid=True), ForeignKey("cuadriculas.id"))
    tipo_sensor = Column(String)
    dispositivo_id = Column(UUID(as_uuid=True), ForeignKey("dispositivos.id"))
    fecha_instalacion = Column(Date)
