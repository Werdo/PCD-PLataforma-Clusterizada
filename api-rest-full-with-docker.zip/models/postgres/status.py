
from sqlalchemy import Column, String, DateTime
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Estado(Base):
    __tablename__ = "estados"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    objeto_id = Column(UUID(as_uuid=True))
    clase_objeto = Column(String)
    estado = Column(String)
    timestamp_inicio = Column(DateTime)
    timestamp_fin = Column(DateTime, nullable=True)
