
from sqlalchemy import Column, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from database.postgres import Base
import uuid

class Trazabilidad(Base):
    __tablename__ = "trazabilidad"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    objeto_id = Column(UUID(as_uuid=True))
    clase_objeto = Column(String)
    ubicacion_anterior_id = Column(UUID(as_uuid=True))
    ubicacion_nueva_id = Column(UUID(as_uuid=True))
    fecha_movimiento = Column(DateTime)
