
from pydantic import BaseModel
from typing import Optional
from uuid import UUID

class UbicacionBase(BaseModel):
    nombre: str
    tipo: str
    coordenadas: Optional[str]
    ubicacion_padre_id: Optional[UUID]

class UbicacionCreate(UbicacionBase): pass

class Ubicacion(UbicacionBase):
    id: UUID
    class Config:
        orm_mode = True
