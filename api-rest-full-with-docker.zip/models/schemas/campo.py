
from pydantic import BaseModel
from uuid import UUID
from typing import Optional
from datetime import date

class ParcelaBase(BaseModel):
    nombre: str
    ubicacion_id: UUID
    superficie: float
    tipo_tenencia: str
    activo: bool = True

class ParcelaCreate(ParcelaBase): pass

class Parcela(ParcelaBase):
    id: UUID
    class Config:
        orm_mode = True

class CuadriculaBase(BaseModel):
    parcela_id: UUID
    nombre_local: str
    coordenadas: Optional[str]
    uso: Optional[str]

class CuadriculaCreate(CuadriculaBase): pass

class Cuadricula(CuadriculaBase):
    id: UUID
    class Config:
        orm_mode = True

class SensorCampoBase(BaseModel):
    cuadrícula_id: UUID
    tipo_sensor: str
    dispositivo_id: UUID
    fecha_instalacion: date

class SensorCampoCreate(SensorCampoBase): pass

class SensorCampo(SensorCampoBase):
    id: UUID
    class Config:
        orm_mode = True
