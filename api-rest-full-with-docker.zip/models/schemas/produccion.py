
from pydantic import BaseModel
from typing import Optional
from uuid import UUID
from datetime import datetime

class ProcesoProduccionBase(BaseModel):
    tipo_proceso: str
    objeto_id: UUID
    fecha_inicio: datetime
    fecha_fin: datetime
    resultado: Optional[dict]

class ProcesoProduccionCreate(ProcesoProduccionBase): pass

class ProcesoProduccion(ProcesoProduccionBase):
    id: UUID
    class Config:
        orm_mode = True

class TrazabilidadBase(BaseModel):
    objeto_id: UUID
    clase_objeto: str
    ubicacion_anterior_id: UUID
    ubicacion_nueva_id: UUID
    fecha_movimiento: datetime

class TrazabilidadCreate(TrazabilidadBase): pass

class Trazabilidad(TrazabilidadBase):
    id: UUID
    class Config:
        orm_mode = True

class ValorFermentacionBase(BaseModel):
    proceso_id: UUID
    tipo_valor: str
    valor: float
    timestamp: datetime

class ValorFermentacionCreate(ValorFermentacionBase): pass

class ValorFermentacion(ValorFermentacionBase):
    id: UUID
    class Config:
        orm_mode = True
