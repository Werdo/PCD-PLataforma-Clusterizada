
from pydantic import BaseModel
from uuid import UUID
from typing import Optional

class DispositivoBase(BaseModel):
    tipo: str
    marca: str
    modelo: str
    ubicacion_id: UUID
    activo: bool = True

class DispositivoCreate(DispositivoBase): pass

class Dispositivo(DispositivoBase):
    id: UUID
    class Config:
        orm_mode = True

class SensorBase(BaseModel):
    dispositivo_id: UUID
    tipo_sensor: str
    unidad_medida: str
    rango_operativo: Optional[str]

class SensorCreate(SensorBase): pass

class Sensor(SensorBase):
    id: UUID
    class Config:
        orm_mode = True

class EstadoBase(BaseModel):
    objeto_id: UUID
    clase_objeto: str
    estado: str
    timestamp_inicio: str
    timestamp_fin: Optional[str]

class EstadoCreate(EstadoBase): pass

class Estado(EstadoBase):
    id: UUID
    class Config:
        orm_mode = True
