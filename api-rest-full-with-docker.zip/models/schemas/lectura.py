
from pydantic import BaseModel
from typing import Optional, Any
from datetime import datetime

class LecturaIn(BaseModel):
    sensor_id: str
    timestamp: datetime
    valor: float
    unidad: Optional[str]
    metadata: Optional[dict]

class LecturaOut(LecturaIn):
    id: str

class EventoIn(BaseModel):
    objeto_afectado_id: str
    clase_objeto: str
    tipo_evento: str
    timestamp: datetime
    metadatos: Optional[dict]

class EventoOut(EventoIn):
    id: str
