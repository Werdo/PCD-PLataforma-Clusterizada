
from pydantic import BaseSettings

class Settings(BaseSettings):
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "centraldb"
    POSTGRES_USER: str = "admin"
    POSTGRES_PASSWORD: str = "secret"
    MONGODB_URI: str = "mongodb://admin:secret@mongodb:27017"
    SECRET_KEY: str = "supersecretkey"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    class Config:
        env_file = ".env"

settings = Settings()
