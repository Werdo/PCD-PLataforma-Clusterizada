
from fastapi import APIRouter
from typing import List

router = APIRouter(prefix="/catalogos", tags=["catalogos"])

@router.get("/")
def get_catalogos():
    return {"status": "Catálogos disponibles"}
