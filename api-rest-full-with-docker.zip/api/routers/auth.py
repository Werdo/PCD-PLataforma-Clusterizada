
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from models.schemas.user import UserCreate
from crud import users
from database.postgres import SessionLocal
from core.security import create_access_token, verify_password
from jose import JWTError
from fastapi.security import OAuth2PasswordRequestForm
from models.postgres.user import User

router = APIRouter(prefix="/auth", tags=["auth"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = users.get_user_by_email(db, form_data.username)
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect credentials")
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}
