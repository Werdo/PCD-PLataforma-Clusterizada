
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.postgres.barrel import Barrica
from typing import List

router = APIRouter(prefix="/barricas", tags=["infraestructura"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_model=List[dict])
def listar_barricas(db: Session = Depends(get_db)):
    return db.query(Barrica).all()
