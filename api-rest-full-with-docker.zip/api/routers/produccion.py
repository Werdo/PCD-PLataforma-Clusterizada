
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.schemas.produccion import (
    ProcesoProduccionCreate, ProcesoProduccion,
    TrazabilidadCreate, Trazabilidad,
    ValorFermentacionCreate, ValorFermentacion
)
from crud import produccion

router = APIRouter(prefix="/produccion", tags=["produccion"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/procesos", response_model=ProcesoProduccion)
def crear_proceso(data: ProcesoProduccionCreate, db: Session = Depends(get_db)):
    return produccion.crear_proceso(db, data)

@router.get("/procesos", response_model=list[ProcesoProduccion])
def listar_procesos(db: Session = Depends(get_db)):
    return produccion.listar_procesos(db)

@router.post("/trazabilidad", response_model=Trazabilidad)
def crear_trazabilidad(data: TrazabilidadCreate, db: Session = Depends(get_db)):
    return produccion.crear_trazabilidad(db, data)

@router.get("/trazabilidad", response_model=list[Trazabilidad])
def listar_trazabilidad(db: Session = Depends(get_db)):
    return produccion.listar_trazabilidad(db)

@router.post("/fermentacion", response_model=ValorFermentacion)
def crear_valor(data: ValorFermentacionCreate, db: Session = Depends(get_db)):
    return produccion.crear_valor_fermentacion(db, data)

@router.get("/fermentacion", response_model=list[ValorFermentacion])
def listar_valores(db: Session = Depends(get_db)):
    return produccion.listar_valores_fermentacion(db)
