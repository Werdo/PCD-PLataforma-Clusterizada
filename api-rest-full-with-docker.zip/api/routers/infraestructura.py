
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.schemas.infrastructure import UbicacionCreate, Ubicacion
from crud import infraestructura

router = APIRouter(prefix="/ubicaciones", tags=["infraestructura"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=Ubicacion)
def crear_ubicacion(data: UbicacionCreate, db: Session = Depends(get_db)):
    return infraestructura.crear_ubicacion(db, data)

@router.get("/", response_model=list[Ubicacion])
def listar_ubicaciones(db: Session = Depends(get_db)):
    return infraestructura.listar_ubicaciones(db)
