
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.postgres.jaulon import Jaulon
from typing import List

router = APIRouter(prefix="/jaulones", tags=["infraestructura"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_model=List[dict])
def listar_jaulones(db: Session = Depends(get_db)):
    return db.query(Jaulon).all()
