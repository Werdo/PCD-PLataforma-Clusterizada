
from fastapi import APIRouter

router = APIRouter(prefix="/parametrizacion", tags=["parametrizacion"])

@router.get("/")
def get_parametros():
    return {"status": "Parámetros disponibles"}
