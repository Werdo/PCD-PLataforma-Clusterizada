
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.postgres.room import Sala
from typing import List
from uuid import UUID

router = APIRouter(prefix="/salas", tags=["infraestructura"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_model=List[dict])
def listar_salas(db: Session = Depends(get_db)):
    return db.query(Sala).all()
