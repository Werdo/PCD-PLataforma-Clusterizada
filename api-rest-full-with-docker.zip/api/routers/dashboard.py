
from fastapi import APIRouter

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@router.get("/")
def obtener_panel_general():
    return {
        "estado": "ok",
        "componentes": [
            "usuarios", "dispositivos", "sensores",
            "eventos", "energía", "clima", "producción"
        ]
    }
