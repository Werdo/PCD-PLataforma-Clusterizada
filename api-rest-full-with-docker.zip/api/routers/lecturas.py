
from fastapi import APIRouter, HTTPException
from models.schemas.lectura import LecturaIn, LecturaOut
from crud.mongodb import guardar_lectura, listar_lecturas

router = APIRouter(prefix="/lecturas", tags=["lecturas"])

@router.post("/", response_model=str)
async def crear_lectura(data: LecturaIn):
    return await guardar_lectura(data.dict())

@router.get("/", response_model=list[LecturaOut])
async def obtener_lecturas(sensor_id: str = None):
    return await listar_lecturas(sensor_id)
