
from fastapi import APIRouter, UploadFile, File

router = APIRouter(prefix="/importacion", tags=["importacion"])

@router.post("/{entidad}")
async def importar_csv(entidad: str, archivo: UploadFile = File(...)):
    contenido = await archivo.read()
    # TODO: lógica de importación para cada entidad
    return {"entidad": entidad, "tamaño_archivo": len(contenido)}
