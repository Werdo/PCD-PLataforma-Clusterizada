
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.schemas.user import UserCreate, User
from crud import users

router = APIRouter(prefix="/usuarios", tags=["usuarios"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=User)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    return users.create_user(db, user)
