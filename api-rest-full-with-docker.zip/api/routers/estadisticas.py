
from fastapi import APIRouter
from datetime import datetime

router = APIRouter(prefix="/estadisticas", tags=["estadisticas"])

@router.get("/uso-sensores")
def uso_sensores():
    # TODO: consulta agregada real
    return {
        "total_lecturas": 124589,
        "sensores_activados": 89,
        "timestamp": datetime.utcnow()
    }

@router.get("/eventos")
def eventos_resumen():
    return {
        "eventos_ultimo_dia": 320,
        "tipos_eventos": {"alerta": 212, "mantenimiento": 68, "otros": 40}
    }
