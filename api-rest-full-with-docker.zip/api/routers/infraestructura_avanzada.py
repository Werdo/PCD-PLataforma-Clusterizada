
from fastapi import APIRouter

router = APIRouter(prefix="/infraestructura", tags=["infraestructura avanzada"])

@router.get("/")
def info_infraestructura():
    return {"status": "Infraestructura energética e inteligente integrada"}
