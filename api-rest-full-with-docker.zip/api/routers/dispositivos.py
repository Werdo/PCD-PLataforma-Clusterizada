
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.schemas.dispositivos import (
    DispositivoCreate, Dispositivo,
    SensorCreate, Sensor,
    EstadoCreate, Estado
)
from crud import dispositivos

router = APIRouter(prefix="/dispositivos", tags=["dispositivos"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=Dispositivo)
def crear_dispositivo(data: DispositivoCreate, db: Session = Depends(get_db)):
    return dispositivos.crear_dispositivo(db, data)

@router.get("/", response_model=list[Dispositivo])
def listar_dispositivos(db: Session = Depends(get_db)):
    return dispositivos.listar_dispositivos(db)

@router.post("/sensores", response_model=Sensor)
def crear_sensor(data: SensorCreate, db: Session = Depends(get_db)):
    return dispositivos.crear_sensor(db, data)

@router.get("/sensores", response_model=list[Sensor])
def listar_sensores(db: Session = Depends(get_db)):
    return dispositivos.listar_sensores(db)

@router.post("/estados", response_model=Estado)
def crear_estado(data: EstadoCreate, db: Session = Depends(get_db)):
    return dispositivos.crear_estado(db, data)

@router.get("/estados", response_model=list[Estado])
def listar_estados(db: Session = Depends(get_db)):
    return dispositivos.listar_estados(db)
