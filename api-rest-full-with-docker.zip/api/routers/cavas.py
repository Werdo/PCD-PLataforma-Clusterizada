
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.postgres.cava import Cava
from typing import List

router = APIRouter(prefix="/cavas", tags=["infraestructura"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/", response_model=List[dict])
def listar_cavas(db: Session = Depends(get_db)):
    return db.query(Cava).all()
