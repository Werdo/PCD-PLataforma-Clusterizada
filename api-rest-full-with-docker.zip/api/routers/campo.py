
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database.postgres import SessionLocal
from models.schemas.campo import (
    ParcelaCreate, Parcela,
    CuadriculaCreate, Cuadricula,
    SensorCampoCreate, SensorCampo
)
from crud import campo

router = APIRouter(prefix="/campo", tags=["campo"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/parcelas", response_model=Parcela)
def crear_parcela(data: ParcelaCreate, db: Session = Depends(get_db)):
    return campo.crear_parcela(db, data)

@router.get("/parcelas", response_model=list[Parcela])
def listar_parcelas(db: Session = Depends(get_db)):
    return campo.listar_parcelas(db)

@router.post("/cuadriculas", response_model=Cuadricula)
def crear_cuadricula(data: CuadriculaCreate, db: Session = Depends(get_db)):
    return campo.crear_cuadricula(db, data)

@router.get("/cuadriculas", response_model=list[Cuadricula])
def listar_cuadriculas(db: Session = Depends(get_db)):
    return campo.listar_cuadriculas(db)

@router.post("/sensores", response_model=SensorCampo)
def crear_sensor(data: SensorCampoCreate, db: Session = Depends(get_db)):
    return campo.crear_sensor_campo(db, data)

@router.get("/sensores", response_model=list[SensorCampo])
def listar_sensores(db: Session = Depends(get_db)):
    return campo.listar_sensores_campo(db)
