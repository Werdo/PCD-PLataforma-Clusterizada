
from fastapi import APIRouter
from models.schemas.lectura import EventoIn, EventoOut
from crud.mongodb import guardar_evento, listar_eventos

router = APIRouter(prefix="/eventos", tags=["eventos"])

@router.post("/", response_model=str)
async def crear_evento(data: EventoIn):
    return await guardar_evento(data.dict())

@router.get("/", response_model=list[EventoOut])
async def obtener_eventos(clase_objeto: str = None):
    return await listar_eventos(clase_objeto)
