
from sqlalchemy.orm import Session
from models.postgres.location import Ubicacion
from models.schemas.infrastructure import UbicacionCreate
import uuid

def crear_ubicacion(db: Session, data: UbicacionCreate):
    ubicacion = Ubicacion(**data.dict())
    db.add(ubicacion)
    db.commit()
    db.refresh(ubicacion)
    return ubicacion

def listar_ubicaciones(db: Session):
    return db.query(Ubicacion).all()
