
from motor.motor_asyncio import AsyncIOMotorClient
from core.config import settings
from datetime import datetime

client = AsyncIOMotorClient(settings.MONGODB_URI)
db = client["pcd"]

async def guardar_lectura(data: dict):
    result = await db.lecturas.insert_one(data)
    return str(result.inserted_id)

async def listar_lecturas(sensor_id: str = None):
    filtro = {"sensor_id": sensor_id} if sensor_id else {}
    lecturas = db.lecturas.find(filtro).sort("timestamp", -1).limit(100)
    return [dict(item, id=str(item["_id"])) async for item in lecturas]

async def guardar_evento(data: dict):
    result = await db.eventos.insert_one(data)
    return str(result.inserted_id)

async def listar_eventos(clase_objeto: str = None):
    filtro = {"clase_objeto": clase_objeto} if clase_objeto else {}
    eventos = db.eventos.find(filtro).sort("timestamp", -1).limit(100)
    return [dict(item, id=str(item["_id"])) async for item in eventos]
