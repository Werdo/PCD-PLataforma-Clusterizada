
from sqlalchemy.orm import Session
from models.postgres.plot import Parcela
from models.postgres.grid import Cuadricula
from models.postgres.field_sensor import SensorCampo
from models.schemas.campo import ParcelaCreate, CuadriculaCreate, SensorCampoCreate

def crear_parcela(db: Session, data: ParcelaCreate):
    parcela = Parcela(**data.dict())
    db.add(parcela)
    db.commit()
    db.refresh(parcela)
    return parcela

def listar_parcelas(db: Session):
    return db.query(Parcela).all()

def crear_cuadricula(db: Session, data: CuadriculaCreate):
    cuadricula = Cuadricula(**data.dict())
    db.add(cuadricula)
    db.commit()
    db.refresh(cuadricula)
    return cuadricula

def listar_cuadriculas(db: Session):
    return db.query(Cuadricula).all()

def crear_sensor_campo(db: Session, data: SensorCampoCreate):
    sensor = SensorCampo(**data.dict())
    db.add(sensor)
    db.commit()
    db.refresh(sensor)
    return sensor

def listar_sensores_campo(db: Session):
    return db.query(SensorCampo).all()
