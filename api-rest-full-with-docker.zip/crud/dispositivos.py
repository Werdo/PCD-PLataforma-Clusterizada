
from sqlalchemy.orm import Session
from models.postgres.device import Dispositivo
from models.postgres.sensor import Sensor
from models.postgres.status import Estado
from models.schemas.dispositivos import DispositivoCreate, SensorCreate, EstadoCreate

def crear_dispositivo(db: Session, data: DispositivoCreate):
    d = Dispositivo(**data.dict())
    db.add(d)
    db.commit()
    db.refresh(d)
    return d

def listar_dispositivos(db: Session):
    return db.query(Dispositivo).all()

def crear_sensor(db: Session, data: SensorCreate):
    s = Sensor(**data.dict())
    db.add(s)
    db.commit()
    db.refresh(s)
    return s

def listar_sensores(db: Session):
    return db.query(Sensor).all()

def crear_estado(db: Session, data: EstadoCreate):
    e = Estado(**data.dict())
    db.add(e)
    db.commit()
    db.refresh(e)
    return e

def listar_estados(db: Session):
    return db.query(Estado).all()
