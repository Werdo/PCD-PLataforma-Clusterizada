
from sqlalchemy.orm import Session
from models.postgres.production import ProcesoProduccion
from models.postgres.trazabilidad import Trazabilidad
from models.postgres.fermentacion import ValorFermentacion
from models.schemas.produccion import (
    ProcesoProduccionCreate,
    TrazabilidadCreate,
    ValorFermentacionCreate
)

def crear_proceso(db: Session, data: ProcesoProduccionCreate):
    item = ProcesoProduccion(**data.dict())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

def listar_procesos(db: Session):
    return db.query(ProcesoProduccion).all()

def crear_trazabilidad(db: Session, data: TrazabilidadCreate):
    item = Trazabilidad(**data.dict())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

def listar_trazabilidad(db: Session):
    return db.query(Trazabilidad).all()

def crear_valor_fermentacion(db: Session, data: ValorFermentacionCreate):
    item = ValorFermentacion(**data.dict())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

def listar_valores_fermentacion(db: Session):
    return db.query(ValorFermentacion).all()
