
from fastapi import FastAPI
from api.routers import auth, users

app = FastAPI(title="PCD API REST")

app.include_router(auth.router)
app.include_router(users.router)

@app.get("/health")
def health_check():
    return {"status": "ok"}
